#include "Obstacle.h"

char Obstacle::getShape() const {
  return '~';
}
