#include "Ship.h"

char EnemyW::getShape() const {
	return 'W';
}

char Enemyu::getShape() const {
	return 'u';
}

char PlayerShip::getShape() const {
	return '^';
}
